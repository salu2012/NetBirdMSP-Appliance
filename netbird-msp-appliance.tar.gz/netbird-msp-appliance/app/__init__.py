"""
NetBird MSP Appliance
Multi-Tenant NetBird Management Platform
"""

__version__ = "1.0.0"
__author__ = "NetBird MSP Contributors"

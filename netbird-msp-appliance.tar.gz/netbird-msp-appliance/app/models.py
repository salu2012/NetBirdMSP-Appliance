"""
Database models for NetBird MSP Appliance
"""

from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base


class Customer(Base):
    """Customer/Tenant model"""
    __tablename__ = "customers"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    company = Column(String(150))
    subdomain = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(150), nullable=False)
    max_devices = Column(Integer, default=20)
    notes = Column(Text)
    status = Column(String(20), default='active')  # active, inactive, deploying, error
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())
    
    # Relationships
    deployment = relationship("Deployment", back_populates="customer", uselist=False, cascade="all, delete-orphan")
    logs = relationship("DeploymentLog", back_populates="customer", cascade="all, delete-orphan")


class Deployment(Base):
    """Deployment information for each customer"""
    __tablename__ = "deployments"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    customer_id = Column(Integer, ForeignKey('customers.id', ondelete='CASCADE'), unique=True, nullable=False)
    container_prefix = Column(String(100), nullable=False)
    relay_udp_port = Column(Integer, unique=True, nullable=False)
    npm_proxy_id = Column(Integer)
    relay_secret = Column(String(100), nullable=False)
    setup_url = Column(String(200))
    deployment_status = Column(String(20), default='pending')  # pending, running, stopped, failed
    deployed_at = Column(DateTime(timezone=True), server_default=func.now())
    last_health_check = Column(DateTime(timezone=True))
    
    # Relationships
    customer = relationship("Customer", back_populates="deployment")


class SystemConfig(Base):
    """System configuration (single row)"""
    __tablename__ = "system_config"
    
    id = Column(Integer, primary_key=True)  # Always 1
    base_domain = Column(String(100), nullable=False)
    admin_email = Column(String(150), nullable=False)
    npm_api_url = Column(String(200), nullable=False)
    npm_api_token_encrypted = Column(Text, nullable=False)
    netbird_management_image = Column(String(100), default='netbirdio/management:latest')
    netbird_signal_image = Column(String(100), default='netbirdio/signal:latest')
    netbird_relay_image = Column(String(100), default='netbirdio/relay:latest')
    netbird_dashboard_image = Column(String(100), default='netbirdio/dashboard:latest')
    data_dir = Column(String(200), default='/opt/netbird-instances')
    docker_network = Column(String(100), default='npm-network')
    relay_base_port = Column(Integer, default=3478)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())


class DeploymentLog(Base):
    """Deployment activity logs"""
    __tablename__ = "deployment_logs"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    customer_id = Column(Integer, ForeignKey('customers.id', ondelete='CASCADE'), nullable=False)
    action = Column(String(100), nullable=False)
    status = Column(String(20), nullable=False)  # success, error, info
    message = Column(Text)
    details = Column(Text)  # JSON string
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    
    # Relationships
    customer = relationship("Customer", back_populates="logs")


class User(Base):
    """Admin users"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    password_hash = Column(String(200), nullable=False)
    email = Column(String(150))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

#!/bin/bash

# NetBird MSP Appliance - Installation Script
# This script sets up the complete NetBird MSP management platform

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/opt/netbird-msp"
DATA_DIR="/opt/netbird-instances"
DOCKER_NETWORK="npm-network"
CONTAINER_NAME="netbird-msp-appliance"

echo -e "${BLUE}"
cat << 'BANNER'
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║       NetBird MSP Appliance Installation Script          ║
║                                                           ║
║   Multi-Tenant NetBird Management Platform               ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
BANNER
echo -e "${NC}"

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}Error: This script must be run as root${NC}"
   echo "Please run: sudo $0"
   exit 1
fi

echo -e "${GREEN}Starting installation...${NC}\n"

# Step 1: System Requirements Check
echo -e "${BLUE}[1/8]${NC} Checking system requirements..."

# Check CPU cores
CPU_CORES=$(nproc)
if [ "$CPU_CORES" -lt 4 ]; then
    echo -e "${YELLOW}Warning: Only $CPU_CORES CPU cores detected. Minimum 8 recommended for 100 customers.${NC}"
else
    echo -e "${GREEN}✓ CPU cores: $CPU_CORES${NC}"
fi

# Check RAM
TOTAL_RAM=$(free -g | awk '/^Mem:/{print $2}')
if [ "$TOTAL_RAM" -lt 32 ]; then
    echo -e "${YELLOW}Warning: Only ${TOTAL_RAM}GB RAM detected. Minimum 64GB recommended for 100 customers.${NC}"
else
    echo -e "${GREEN}✓ RAM: ${TOTAL_RAM}GB${NC}"
fi

# Check disk space
DISK_SPACE=$(df -BG / | awk 'NR==2 {print $4}' | sed 's/G//')
if [ "$DISK_SPACE" -lt 200 ]; then
    echo -e "${YELLOW}Warning: Only ${DISK_SPACE}GB free disk space. Minimum 500GB recommended.${NC}"
else
    echo -e "${GREEN}✓ Disk space: ${DISK_SPACE}GB${NC}"
fi

# Step 2: Install Docker
echo -e "\n${BLUE}[2/8]${NC} Checking Docker installation..."

if ! command -v docker &> /dev/null; then
    echo "Docker not found. Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
    systemctl enable docker
    systemctl start docker
    echo -e "${GREEN}✓ Docker installed${NC}"
else
    DOCKER_VERSION=$(docker --version | awk '{print $3}' | sed 's/,//')
    echo -e "${GREEN}✓ Docker already installed (${DOCKER_VERSION})${NC}"
fi

# Check Docker Compose
if ! docker compose version &> /dev/null; then
    echo -e "${RED}Error: Docker Compose plugin not found${NC}"
    echo "Please install Docker Compose plugin: https://docs.docker.com/compose/install/"
    exit 1
else
    echo -e "${GREEN}✓ Docker Compose available${NC}"
fi

# Step 3: Create directories
echo -e "\n${BLUE}[3/8]${NC} Creating directories..."

mkdir -p "$INSTALL_DIR"
mkdir -p "$DATA_DIR"
mkdir -p "$INSTALL_DIR/data"
mkdir -p "$INSTALL_DIR/logs"
mkdir -p "$INSTALL_DIR/backups"

echo -e "${GREEN}✓ Directories created${NC}"

# Step 4: Create Docker network
echo -e "\n${BLUE}[4/8]${NC} Setting up Docker network..."

if docker network inspect $DOCKER_NETWORK &> /dev/null; then
    echo -e "${GREEN}✓ Docker network '$DOCKER_NETWORK' already exists${NC}"
else
    docker network create $DOCKER_NETWORK
    echo -e "${GREEN}✓ Docker network '$DOCKER_NETWORK' created${NC}"
fi

# Step 5: Generate secrets
echo -e "\n${BLUE}[5/8]${NC} Generating secure secrets..."

SECRET_KEY=$(openssl rand -base64 32)
ADMIN_PASSWORD=$(openssl rand -base64 16)

cat > "$INSTALL_DIR/.env" << ENVEOF
# NetBird MSP Appliance Configuration
# Generated on $(date)

# Security
SECRET_KEY=$SECRET_KEY
ADMIN_USERNAME=admin
ADMIN_PASSWORD=$ADMIN_PASSWORD

# Nginx Proxy Manager (CONFIGURE THESE AFTER INSTALLATION)
NPM_API_URL=http://nginx-proxy-manager:81/api
NPM_API_TOKEN=CHANGE_ME

# System
DATA_DIR=$DATA_DIR
DOCKER_NETWORK=$DOCKER_NETWORK
BASE_DOMAIN=yourdomain.com
ADMIN_EMAIL=admin@yourdomain.com

# NetBird Images
NETBIRD_MANAGEMENT_IMAGE=netbirdio/management:latest
NETBIRD_SIGNAL_IMAGE=netbirdio/signal:latest
NETBIRD_RELAY_IMAGE=netbirdio/relay:latest
NETBIRD_DASHBOARD_IMAGE=netbirdio/dashboard:latest

# Database
DATABASE_PATH=/app/data/netbird_msp.db

# Logging
LOG_LEVEL=INFO
ENVEOF

chmod 600 "$INSTALL_DIR/.env"
echo -e "${GREEN}✓ Environment file created${NC}"

# Step 6: Copy application files
echo -e "\n${BLUE}[6/8]${NC} Copying application files..."

# Copy everything to install directory
cp -r ./* "$INSTALL_DIR/" 2>/dev/null || true
cd "$INSTALL_DIR"

echo -e "${GREEN}✓ Files copied to $INSTALL_DIR${NC}"

# Step 7: Build and start containers
echo -e "\n${BLUE}[7/8]${NC} Building and starting containers..."

docker compose up -d --build

# Wait for container to be ready
echo "Waiting for application to start..."
sleep 10

if docker ps | grep -q $CONTAINER_NAME; then
    echo -e "${GREEN}✓ Container started successfully${NC}"
else
    echo -e "${RED}Error: Container failed to start${NC}"
    echo "Check logs with: docker logs $CONTAINER_NAME"
    exit 1
fi

# Step 8: Initialize database
echo -e "\n${BLUE}[8/8]${NC} Initializing database..."

docker exec $CONTAINER_NAME python -m app.database init || true

echo -e "${GREEN}✓ Database initialized${NC}"

# Display completion message
echo -e "\n${GREEN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}║        ✓ Installation Complete!                           ║${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════╝${NC}"

echo -e "\n${BLUE}Next Steps:${NC}"
echo ""
echo "1. Access the web interface:"
echo -e "   ${GREEN}http://$(hostname -I | awk '{print $1}'):8000${NC}"
echo ""
echo "2. Login credentials:"
echo -e "   Username: ${GREEN}admin${NC}"
echo -e "   Password: ${GREEN}$ADMIN_PASSWORD${NC}"
echo -e "   ${YELLOW}(Change this password immediately!)${NC}"
echo ""
echo "3. Configure system settings in the web UI:"
echo "   - Set your base domain"
echo "   - Configure NPM API credentials"
echo "   - Review firewall rules"
echo ""
echo "4. Open required firewall ports:"
echo -e "   ${YELLOW}sudo ufw allow 8000/tcp${NC}  # Web UI"
echo -e "   ${YELLOW}sudo ufw allow 3478:3577/udp${NC}  # NetBird relay ports"
echo ""
echo "5. Installation directory: ${INSTALL_DIR}"
echo ""
echo -e "${BLUE}Useful commands:${NC}"
echo "   View logs:    docker logs -f $CONTAINER_NAME"
echo "   Stop:         docker compose -f $INSTALL_DIR/docker-compose.yml stop"
echo "   Start:        docker compose -f $INSTALL_DIR/docker-compose.yml start"
echo "   Restart:      docker compose -f $INSTALL_DIR/docker-compose.yml restart"
echo ""
echo -e "${GREEN}Happy MSP-ing! 🚀${NC}"
echo ""

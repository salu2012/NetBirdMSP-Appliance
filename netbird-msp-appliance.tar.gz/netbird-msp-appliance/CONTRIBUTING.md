# Contributing to NetBird MSP Appliance

Thank you for your interest in contributing! 🎉

## How to Contribute

### Reporting Bugs
1. Check existing issues first
2. Create a new issue with:
   - Clear description
   - Steps to reproduce
   - Expected vs actual behavior
   - System info (OS, Docker version, etc.)
   - Logs (if applicable)

### Suggesting Features
1. Open an issue with "Feature Request" label
2. Describe the use case
3. Explain why it would be useful

### Code Contributions

#### Setup Development Environment
```bash
# Clone repository
git clone https://github.com/yourusername/netbird-msp-appliance.git
cd netbird-msp-appliance

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt  # Dev dependencies

# Run tests
pytest
```

#### Code Style
- Follow PEP 8 for Python code
- Use type hints
- Write docstrings for all functions/classes
- Keep functions small and focused
- Add comments for complex logic

#### Pull Request Process
1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass: `pytest`
6. Update documentation if needed
7. Commit with clear messages
8. Push and create pull request

#### Commit Messages
```
feat: Add bulk update functionality
fix: Fix NPM integration port issue
docs: Update installation guide
test: Add tests for deployment service
refactor: Improve error handling in docker service
```

### Testing
- Write unit tests for new code
- Ensure existing tests still pass
- Test manually in a VM before submitting

## Questions?
Open a discussion or reach out via issues!

Thanks for contributing! 🙏
